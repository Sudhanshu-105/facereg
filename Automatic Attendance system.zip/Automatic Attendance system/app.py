from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    choices = [str(x) for x in request.form.values()]
    choice = int(choices[0])
    ch=1
    #while ch!=0 and choice !=4:
    if choice==1:
        import sqlpy as mark
        mark.first()
    elif choice==2:
        import report as mark2
        mark2.rep()
        print("\nReport generated successfully")
    else:
        print("Invalid choice, please choose again")
        print("\n")
    print("")
    print(".")
    import sqlite3
    conn= sqlite3.connect('students.db')
    #for i in range(0, 2):
    cnd="UPDATE STUDENTS SET ATTENDANCE = 0 WHERE ID = 1 OR ID = 2 OR ID = 3"
    cursor=conn.execute(cnd)
    conn.commit()
    conn.close()
    print(choice)
    return render_template('index.html', prediction_text=choice)


if __name__ == "__main__":
    app.run(debug=True)